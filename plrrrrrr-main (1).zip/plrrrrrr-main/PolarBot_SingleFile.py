# ================================================================
#  POLARBOT 2.0 — SINGLE FILE EDITION
#  Run: python PolarBot_SingleFile.py
#
#  STEP 1 — Paste your Discord bot token below (between the quotes)
#  STEP 2 — Install deps:
#    pip install discord.py aiohttp googlesearch-python
#  STEP 3 — python PolarBot_SingleFile.py
# ================================================================

TOKEN = "MTUwNzY4MzU2NDg5NDgxNDIyOA.GEX44v.wvvwHMfl3T8gWpiU7jt-_MC8H3fGd9hu2u1-38"

# ================================================================
#  IMPORTS
# ================================================================
import os, json, ast, operator, asyncio, random, re, time, html
import urllib.parse
import aiohttp
import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
from datetime import timedelta

# ================================================================
#  CONFIG
# ================================================================
OWNER_ID = 1147486351864909845
PREFIXES = [",", "!"]

COLORS = {
    "primary":  0x5865F2, "success": 0x57F287, "warning": 0xFEE75C,
    "error":    0xED4245, "info":    0x5DADE2, "purple":  0x9B59B6,
    "pink":     0xFF73FA, "orange":  0xE67E22, "gold":    0xF1C40F,
    "dark":     0x2C2F33,
}
STAFF_PERMS = ["kick_members","ban_members","manage_channels",
               "manage_guild","manage_roles","administrator"]

# ================================================================
#  DATA HELPERS  (saves JSON files to ./data/)
# ================================================================
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(DATA_DIR, exist_ok=True)

def _path(name): return os.path.join(DATA_DIR, f"{name}.json")

def load(name):
    p = _path(name)
    if not os.path.exists(p): return {}
    with open(p) as f: return json.load(f)

def save(name, data):
    with open(_path(name), "w") as f: json.dump(data, f, indent=2)

def get_guild(name, guild_id):
    return load(name).get(str(guild_id), {})

def set_guild(name, guild_id, value):
    data = load(name); data[str(guild_id)] = value; save(name, data)

def is_staff(member):
    if member.id == OWNER_ID: return True
    perms = member.guild_permissions
    if any(getattr(perms, p, False) for p in STAFF_PERMS): return True
    cfg = get_guild("config", member.guild.id)
    rid = cfg.get("staff_role_id")
    if rid:
        role = member.guild.get_role(int(rid))
        if role and role in member.roles: return True
    return False

def can_moderate(mod, target):
    if target.id == OWNER_ID: return False, "❌ You cannot moderate the bot owner."
    if mod.id == target.id:   return False, "❌ You cannot moderate yourself, dum dum 😂"
    if target.top_role >= mod.top_role and mod.id != OWNER_ID:
        return False, "❌ You can't moderate higher ups, dum dum 😂"
    return True, ""

def make_embed(title="", description="", color=0x5865F2,
               footer="", thumbnail="", image=""):
    e = discord.Embed(title=title, description=description, color=color)
    if footer:    e.set_footer(text=footer)
    if thumbnail: e.set_thumbnail(url=thumbnail)
    if image:     e.set_image(url=image)
    return e

def _is_staff_check():
    async def predicate(ctx):
        if not (is_staff(ctx.author) or ctx.author.id == OWNER_ID):
            await ctx.reply(embed=make_embed(
                description="🔒 **This command is for Staff only!**", color=0xED4245))
            return False
        return True
    return commands.check(predicate)

# ================================================================
#  BOT INSTANCE
# ================================================================
intents = discord.Intents.all()
bot = commands.Bot(command_prefix=PREFIXES, intents=intents,
                   help_command=None, case_insensitive=True)
bot.snipe_cache      = {}
bot.editsnipe_cache  = {}
bot.sticky_tasks     = {}

# ================================================================
#  MODERATION COG
# ================================================================
def parse_duration(s):
    s = s.lower().strip()
    if s.endswith("h"): return int(s[:-1]) * 3600
    if s.endswith("m"): return int(s[:-1]) * 60
    if s.endswith("s"): return int(s[:-1])
    return int(s) * 60

class Moderation(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.hybrid_command(name="rn", description="✏️ Rename the current channel")
    @app_commands.describe(name="The new name for the channel")
    @_is_staff_check()
    async def rename_channel(self, ctx, *, name: str):
        old = ctx.channel.name
        await ctx.channel.edit(name=name)
        await ctx.send(embed=make_embed(title="✏️ Channel Renamed",
            description=f"**`#{old}`** → **`#{name}`**", color=0x5865F2,
            footer=f"Renamed by {ctx.author}"))

    @commands.hybrid_command(name="delete", description="🗑️ Delete the current channel")
    @_is_staff_check()
    async def delete_channel(self, ctx):
        await ctx.send(embed=make_embed(description=f"🗑️ **Deleting** `#{ctx.channel.name}`…", color=0xED4245))
        await ctx.channel.delete(reason=f"Deleted by {ctx.author}")

    @commands.hybrid_command(name="ps", description="🎮 Post the Roblox private server link")
    @_is_staff_check()
    async def private_server(self, ctx):
        cfg = get_guild("config", ctx.guild.id)
        link = cfg.get("ps_link")
        if not link:
            await ctx.reply(embed=make_embed(description="❌ No PS link set! Use `,setps <link>`.", color=0xED4245)); return
        await ctx.send(embed=make_embed(title="🎮 Roblox Private Server",
            description=f"[**Click here to join!**]({link})\n`{link}`", color=0x57F287,
            footer=f"Posted by {ctx.author}"))

    @commands.hybrid_command(name="setps", description="🔗 Set the Roblox private server link")
    @app_commands.describe(link="The link")
    @_is_staff_check()
    async def set_ps(self, ctx, *, link: str):
        cfg = get_guild("config", ctx.guild.id); cfg["ps_link"] = link
        set_guild("config", ctx.guild.id, cfg)
        await ctx.reply(embed=make_embed(description=f"✅ PS link set to:\n`{link}`", color=0x57F287))

    @commands.hybrid_command(name="warn", description="⚠️ Warn a member")
    @app_commands.describe(member="Member to warn", reason="Reason")
    @_is_staff_check()
    async def warn(self, ctx, member: discord.Member, reason: str = "No reason provided"):
        ok, msg = can_moderate(ctx.author, member)
        if not ok:
            try: await ctx.author.send(embed=make_embed(description=msg, color=0xED4245))
            except: pass
            await ctx.reply(embed=make_embed(description=msg, color=0xED4245)); return
        data = load("warnings"); gid, uid = str(ctx.guild.id), str(member.id)
        data.setdefault(gid, {}).setdefault(uid, [])
        data[gid][uid].append({"reason": reason, "moderator": str(ctx.author),
            "mod_id": ctx.author.id, "timestamp": int(time.time())})
        save("warnings", data); count = len(data[gid][uid])
        await ctx.send(embed=make_embed(title="⚠️ Member Warned",
            description=f"**Member:** {member.mention}\n**Reason:** {reason}\n**Total Warnings:** `{count}`\n**Moderator:** {ctx.author.mention}",
            color=0xFEE75C, footer=f"Warning #{count}", thumbnail=str(member.display_avatar.url)))
        try:
            await member.send(embed=make_embed(title="⚠️ You Have Been Warned",
                description=f"**Server:** {ctx.guild.name}\n**Reason:** {reason}\n**Total Warnings:** `{count}`",
                color=0xFEE75C))
        except: pass

    @commands.hybrid_command(name="unwarn", description="✅ Remove a member's latest warning")
    @app_commands.describe(member="Member to unwarn")
    @_is_staff_check()
    async def unwarn(self, ctx, member: discord.Member):
        if member.id == ctx.author.id:
            await ctx.reply(embed=make_embed(description="❌ You cannot unwarn yourself, dum dum 😂", color=0xED4245)); return
        data = load("warnings"); gid, uid = str(ctx.guild.id), str(member.id)
        warns = data.get(gid, {}).get(uid, [])
        if not warns:
            await ctx.reply(embed=make_embed(description=f"ℹ️ {member.mention} has no warnings.", color=0x5DADE2)); return
        removed = warns.pop(); data[gid][uid] = warns; save("warnings", data)
        await ctx.send(embed=make_embed(title="✅ Warning Removed",
            description=f"**Member:** {member.mention}\n**Removed:** {removed['reason']}\n**Remaining:** `{len(warns)}`",
            color=0x57F287, thumbnail=str(member.display_avatar.url)))

    @commands.hybrid_command(name="warnings", description="📋 View all warnings for a member")
    @app_commands.describe(member="Member to check")
    @_is_staff_check()
    async def warnings(self, ctx, member: discord.Member):
        data = load("warnings"); warns = data.get(str(ctx.guild.id), {}).get(str(member.id), [])
        if not warns:
            await ctx.reply(embed=make_embed(description=f"✅ {member.mention} has no warnings.",
                color=0x57F287, thumbnail=str(member.display_avatar.url))); return
        lines = [f"**{i}.** {w['reason']} — by `{w['moderator']}` · <t:{w['timestamp']}:R>"
                 for i, w in enumerate(warns, 1)]
        await ctx.send(embed=make_embed(title=f"⚠️ Warnings for {member.display_name}",
            description="\n".join(lines), color=0xFEE75C,
            thumbnail=str(member.display_avatar.url), footer=f"Total: {len(warns)}"))

    @commands.hybrid_command(name="kick", description="👢 Kick a member")
    @app_commands.describe(member="Member to kick", reason="Reason")
    @_is_staff_check()
    async def kick(self, ctx, member: discord.Member, reason: str = "No reason provided"):
        ok, msg = can_moderate(ctx.author, member)
        if not ok: await ctx.reply(embed=make_embed(description=msg, color=0xED4245)); return
        try:
            await member.send(embed=make_embed(title="👢 You Have Been Kicked",
                description=f"**Server:** {ctx.guild.name}\n**Reason:** {reason}", color=0xED4245))
        except: pass
        await member.kick(reason=reason)
        await ctx.send(embed=make_embed(title="👢 Member Kicked",
            description=f"**Member:** {member.mention}\n**Reason:** {reason}\n**By:** {ctx.author.mention}",
            color=0xED4245, thumbnail=str(member.display_avatar.url)))

    @commands.hybrid_command(name="ban", description="🔨 Ban a member")
    @app_commands.describe(member="Member to ban", reason="Reason")
    @_is_staff_check()
    async def ban(self, ctx, member: discord.Member, reason: str = "No reason provided"):
        ok, msg = can_moderate(ctx.author, member)
        if not ok: await ctx.reply(embed=make_embed(description=msg, color=0xED4245)); return
        try:
            await member.send(embed=make_embed(title="🔨 You Have Been Banned",
                description=f"**Server:** {ctx.guild.name}\n**Reason:** {reason}", color=0xED4245))
        except: pass
        await member.ban(reason=reason)
        await ctx.send(embed=make_embed(title="🔨 Member Banned",
            description=f"**Member:** {member.mention}\n**Reason:** {reason}\n**By:** {ctx.author.mention}",
            color=0xED4245, thumbnail=str(member.display_avatar.url)))

    @commands.hybrid_command(name="unban", description="🔓 Unban a user by ID")
    @app_commands.describe(user_id="Discord user ID to unban")
    @_is_staff_check()
    async def unban(self, ctx, user_id: str):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await ctx.guild.unban(user, reason=f"Unbanned by {ctx.author}")
            await ctx.send(embed=make_embed(title="✅ Member Unbanned",
                description=f"**User:** {user} (`{user_id}`)\n**By:** {ctx.author.mention}", color=0x57F287))
        except (ValueError, discord.NotFound):
            await ctx.reply(embed=make_embed(description="❌ User not found in ban list.", color=0xED4245))

    @commands.hybrid_command(name="mute", description="🔇 Timeout a member (e.g. 10m, 1h)")
    @app_commands.describe(member="Member to mute", duration="Duration e.g. 10m 1h 30s", reason="Reason")
    @_is_staff_check()
    async def mute(self, ctx, member: discord.Member, duration: str = "10m", reason: str = "No reason provided"):
        ok, msg = can_moderate(ctx.author, member)
        if not ok: await ctx.reply(embed=make_embed(description=msg, color=0xED4245)); return
        try: secs = parse_duration(duration)
        except ValueError:
            await ctx.reply(embed=make_embed(description="❌ Invalid duration. Use `10m`, `1h`, `30s`.", color=0xED4245)); return
        await member.timeout(discord.utils.utcnow() + timedelta(seconds=secs), reason=reason)
        await ctx.send(embed=make_embed(title="🔇 Member Muted",
            description=f"**Member:** {member.mention}\n**Duration:** `{duration}`\n**Reason:** {reason}\n**By:** {ctx.author.mention}",
            color=0xFEE75C, thumbnail=str(member.display_avatar.url)))
        try:
            await member.send(embed=make_embed(title="🔇 You Have Been Muted",
                description=f"**Server:** {ctx.guild.name}\n**Duration:** `{duration}`\n**Reason:** {reason}",
                color=0xFEE75C))
        except: pass

    @commands.hybrid_command(name="unmute", description="🔊 Remove a member's timeout")
    @app_commands.describe(member="Member to unmute")
    @_is_staff_check()
    async def unmute(self, ctx, member: discord.Member):
        await member.timeout(None)
        await ctx.send(embed=make_embed(title="🔊 Member Unmuted",
            description=f"**Member:** {member.mention}\n**By:** {ctx.author.mention}",
            color=0x57F287, thumbnail=str(member.display_avatar.url)))

    @commands.hybrid_command(name="userinfo", description="👤 View info about a member")
    @app_commands.describe(member="Member to look up")
    @_is_staff_check()
    async def userinfo(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        data = load("warnings")
        warn_count = len(data.get(str(ctx.guild.id), {}).get(str(member.id), []))
        badges = []
        if member.id == OWNER_ID:     badges.append("👑 Bot Owner")
        if is_staff(member):          badges.append("🛡️ Staff")
        if member.bot:                badges.append("🤖 Bot")
        if member.premium_since:      badges.append("💎 Booster")
        roles = [r.mention for r in reversed(member.roles) if r.name != "@everyone"]
        e = discord.Embed(title=f"👤 {member.display_name}",
            color=member.color if member.color.value else 0x5865F2)
        e.set_thumbnail(url=str(member.display_avatar.url))
        e.add_field(name="🪪 User",           value=f"{member} (`{member.id}`)", inline=False)
        e.add_field(name="📅 Created",         value=f"<t:{int(member.created_at.timestamp())}:F>", inline=True)
        e.add_field(name="📥 Joined",          value=f"<t:{int(member.joined_at.timestamp())}:F>", inline=True)
        e.add_field(name="⚠️ Warnings",        value=f"`{warn_count}`", inline=True)
        e.add_field(name="🏷️ Top Role",        value=member.top_role.mention, inline=True)
        e.add_field(name="🎖️ Badges",          value=" · ".join(badges) if badges else "None", inline=False)
        e.add_field(name=f"🎭 Roles ({len(roles)})",
            value=" ".join(roles[:10]) + ("…" if len(roles)>10 else "") if roles else "None", inline=False)
        e.set_footer(text=f"Requested by {ctx.author}")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="purge", description="🗑️ Purge messages from this channel")
    @app_commands.describe(amount="Number of messages (1–500)")
    @_is_staff_check()
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def purge(self, ctx, amount: int = 10):
        if not 1 <= amount <= 500:
            await ctx.reply(embed=make_embed(description="❌ Amount must be 1–500.", color=0xED4245)); return
        await ctx.message.delete()
        deleted = await ctx.channel.purge(limit=amount)
        msg = await ctx.send(embed=make_embed(title="🗑️ Purged",
            description=f"Deleted **{len(deleted)}** message(s). **By:** {ctx.author.mention}", color=0x57F287))
        await asyncio.sleep(4); await msg.delete()

    @commands.hybrid_command(name="setstaff", description="🛡️ Set the staff role")
    @app_commands.describe(role="The staff role")
    @commands.has_permissions(administrator=True)
    async def setstaff(self, ctx, role: discord.Role):
        cfg = get_guild("config", ctx.guild.id); cfg["staff_role_id"] = role.id
        set_guild("config", ctx.guild.id, cfg)
        await ctx.reply(embed=make_embed(description=f"✅ Staff role set to {role.mention}.", color=0x57F287))

# ================================================================
#  UTILITY COG
# ================================================================
class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.update_stats.start()

    def cog_unload(self): self.update_stats.cancel()

    @commands.hybrid_command(name="afk", description="💤 Set your AFK status")
    @app_commands.describe(reason="Why you're going AFK")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def afk(self, ctx, reason: str = "AFK"):
        data = load("afk"); data[str(ctx.author.id)] = {"reason": reason, "since": int(time.time())}
        save("afk", data)
        try: await ctx.author.edit(nick=f"[AFK] {ctx.author.display_name}"[:32])
        except: pass
        await ctx.reply(embed=make_embed(title="💤 AFK Set",
            description=f"{ctx.author.mention} is now AFK\n**Reason:** {reason}", color=0xFEE75C))

    @commands.hybrid_command(name="vouch", description="✅ Vouch a member and close their ticket channel")
    @app_commands.describe(member="Member to vouch")
    @_is_staff_check()
    async def vouch(self, ctx, member: discord.Member):
        await ctx.send(embed=make_embed(title="✅ Member Vouched",
            description=f"**{member.mention}** has been vouched by {ctx.author.mention}!\n\n🌟 *This member is trusted and verified.*",
            color=0x57F287, thumbnail=str(member.display_avatar.url)))
        try: await ctx.channel.delete(reason=f"Ticket vouched by {ctx.author}")
        except: pass

    @commands.hybrid_command(name="snipe", description="🔍 Show the most recently deleted message")
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def snipe(self, ctx):
        entry = self.bot.snipe_cache.get(ctx.channel.id)
        if not entry:
            await ctx.reply(embed=make_embed(description="🕵️ Nothing to snipe!", color=0x5DADE2)); return
        e = discord.Embed(title="🔍 Sniped Message", description=entry["content"], color=0x9B59B6)
        e.set_author(name=entry["author_name"], icon_url=entry["author_avatar"])
        e.set_footer(text=f"Deleted · {entry['timestamp'][:10]}")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="editsnipe", description="✏️ Show the most recently edited message")
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def editsnipe(self, ctx):
        entry = self.bot.editsnipe_cache.get(ctx.channel.id)
        if not entry:
            await ctx.reply(embed=make_embed(description="🕵️ Nothing to edit-snipe!", color=0x5DADE2)); return
        e = discord.Embed(title="✏️ Edit Sniped", color=0x9B59B6)
        e.set_author(name=entry["author_name"], icon_url=entry["author_avatar"])
        e.add_field(name="Before", value=entry["before"][:1024], inline=False)
        e.add_field(name="After",  value=entry["after"][:1024],  inline=False)
        e.set_footer(text=f"Edited · {entry['timestamp'][:10]}")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="sticky", description="📌 Pin a sticky message to the bottom of this channel")
    @app_commands.describe(message="The sticky message text")
    @_is_staff_check()
    async def sticky(self, ctx, message: str):
        sticky_data = get_guild("sticky", ctx.guild.id); cid = str(ctx.channel.id)
        if cid in sticky_data:
            try:
                old = await ctx.channel.fetch_message(sticky_data[cid]["message_id"]); await old.delete()
            except: pass
        msg = await ctx.send(embed=make_embed(title="📌 Sticky Message", description=message, color=0xF1C40F))
        sticky_data[cid] = {"message_id": msg.id, "content": message}
        set_guild("sticky", ctx.guild.id, sticky_data)
        try: await ctx.message.delete()
        except: pass

    @commands.hybrid_command(name="unsticky", description="📌 Remove the sticky message from this channel")
    @_is_staff_check()
    async def unsticky(self, ctx):
        sticky_data = get_guild("sticky", ctx.guild.id); cid = str(ctx.channel.id)
        if cid not in sticky_data:
            await ctx.reply(embed=make_embed(description="❌ No sticky message here.", color=0xED4245)); return
        try:
            msg = await ctx.channel.fetch_message(sticky_data[cid]["message_id"]); await msg.delete()
        except: pass
        del sticky_data[cid]; set_guild("sticky", ctx.guild.id, sticky_data)
        await ctx.reply(embed=make_embed(description="📌 Sticky removed.", color=0x57F287))

    @commands.hybrid_command(name="setstats", description="📊 Create live stat voice channels")
    @_is_staff_check()
    @commands.bot_has_permissions(manage_channels=True)
    async def setstats(self, ctx):
        guild = ctx.guild; cat = await guild.create_category("📊 Server Stats")
        members = sum(1 for m in guild.members if not m.bot)
        bots    = sum(1 for m in guild.members if m.bot)
        boosts  = guild.premium_subscription_count
        vc_m  = await cat.create_voice_channel(f"👥 Members: {members}")
        vc_b  = await cat.create_voice_channel(f"🤖 Bots: {bots}")
        vc_bo = await cat.create_voice_channel(f"🚀 Boosts: {boosts}")
        for vc in [vc_m, vc_b, vc_bo]: await vc.set_permissions(guild.default_role, connect=False)
        cfg = get_guild("config", guild.id)
        cfg["stats"] = {"members_vc": vc_m.id, "bots_vc": vc_b.id, "boosts_vc": vc_bo.id}
        set_guild("config", guild.id, cfg)
        await ctx.send(embed=make_embed(title="📊 Stats Created!",
            description="✅ Stat channels created. They update every **10 minutes**.", color=0x57F287))

    @commands.hybrid_command(name="confess", description="🤫 Send an anonymous confession")
    @app_commands.describe(message="Your anonymous confession")
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def confess(self, ctx, message: str):
        try: await ctx.message.delete()
        except: pass
        guild = channel = None
        if ctx.guild:
            guild = ctx.guild; cfg = get_guild("config", guild.id)
            cid = cfg.get("confession_channel")
            if cid: channel = guild.get_channel(int(cid))
        else:
            for g in self.bot.guilds:
                if ctx.author in g.members:
                    cfg = get_guild("config", g.id); cid = cfg.get("confession_channel")
                    if cid: channel = g.get_channel(int(cid)); guild = g; break
        if not channel:
            await ctx.author.send(embed=make_embed(description="❌ No confession channel set!", color=0xED4245)); return
        data = load("confessions"); gid = str(guild.id); data.setdefault(gid, [])
        num = len(data[gid]) + 1
        data[gid].append({"message": message, "timestamp": int(time.time())}); save("confessions", data)
        await channel.send(embed=make_embed(title=f"🤫 Anonymous Confession #{num}",
            description=f"*{message}*", color=0x9B59B6, footer="React with ❤️ to support"))
        try:
            await ctx.reply(embed=make_embed(description="✅ Confession posted anonymously!", color=0x57F287),
                ephemeral=True, delete_after=5)
        except: pass

    @commands.hybrid_command(name="setconfess", description="🤫 Set the confession channel")
    @app_commands.describe(channel="Channel for confessions")
    @_is_staff_check()
    async def setconfess(self, ctx, channel: discord.TextChannel):
        cfg = get_guild("config", ctx.guild.id); cfg["confession_channel"] = channel.id
        set_guild("config", ctx.guild.id, cfg)
        await ctx.reply(embed=make_embed(description=f"✅ Confession channel set to {channel.mention}.", color=0x57F287))

    @tasks.loop(minutes=10)
    async def update_stats(self):
        for guild in self.bot.guilds:
            cfg = get_guild("config", guild.id); stats = cfg.get("stats")
            if not stats: continue
            try:
                vc_m  = guild.get_channel(stats["members_vc"])
                vc_b  = guild.get_channel(stats["bots_vc"])
                vc_bo = guild.get_channel(stats["boosts_vc"])
                if vc_m:  await vc_m.edit(name=f"👥 Members: {sum(1 for m in guild.members if not m.bot)}")
                if vc_b:  await vc_b.edit(name=f"🤖 Bots: {sum(1 for m in guild.members if m.bot)}")
                if vc_bo: await vc_bo.edit(name=f"🚀 Boosts: {guild.premium_subscription_count}")
            except: pass

    @update_stats.before_loop
    async def before_update_stats(self): await self.bot.wait_until_ready()

# ================================================================
#  AUTO RESPONSE COG
# ================================================================
class AutoResponse(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.hybrid_group(name="autoresponse", description="🤖 Manage auto responses",
        aliases=["ar","autorespond"], invoke_without_command=True, with_app_command=True)
    @_is_staff_check()
    async def autoresponse(self, ctx): await self.ar_list(ctx)

    @autoresponse.command(name="add", description="➕ Add a new auto response trigger")
    @app_commands.describe(trigger="Trigger keyword", response="Bot response")
    @_is_staff_check()
    async def ar_add(self, ctx, trigger: str, response: str):
        data = get_guild("autoresponse", ctx.guild.id); data[trigger.lower()] = response
        set_guild("autoresponse", ctx.guild.id, data)
        await ctx.reply(embed=make_embed(title="✅ Auto Response Added",
            description=f"**Trigger:** `{trigger}`\n**Response:** {response}", color=0x57F287))

    @autoresponse.command(name="remove", description="➖ Remove an auto response trigger")
    @app_commands.describe(trigger="Trigger to remove")
    @_is_staff_check()
    async def ar_remove(self, ctx, trigger: str):
        data = get_guild("autoresponse", ctx.guild.id); key = trigger.lower().strip()
        if key not in data:
            await ctx.reply(embed=make_embed(description=f"❌ No auto response for `{trigger}`.", color=0xED4245)); return
        del data[key]; set_guild("autoresponse", ctx.guild.id, data)
        await ctx.reply(embed=make_embed(description=f"✅ Removed `{trigger}`.", color=0x57F287))

    @autoresponse.command(name="list", description="📋 List all auto responses")
    async def ar_list(self, ctx):
        data = get_guild("autoresponse", ctx.guild.id)
        if not data:
            await ctx.reply(embed=make_embed(description="📭 No auto responses set up.", color=0x5DADE2)); return
        lines = [f"**`{t}`** → {r}" for t, r in list(data.items())[:20]]
        await ctx.send(embed=make_embed(title="🤖 Auto Responses",
            description="\n".join(lines), color=0x5865F2, footer=f"Total: {len(data)}"))

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild: return
        data = get_guild("autoresponse", message.guild.id)
        if not data: return
        content = message.content.lower()
        for trigger, response in data.items():
            if trigger in content: await message.channel.send(response); break

# ================================================================
#  AUTOMOD COG
# ================================================================
class AutoMod(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="automodadd", description="🚫 Add a banned word")
    @app_commands.describe(word="Word to ban")
    async def automodadd(self, interaction: discord.Interaction, word: str):
        if not (is_staff(interaction.user) or interaction.user.id == OWNER_ID):
            await interaction.response.send_message(embed=make_embed(description="🔒 **Staff only!**", color=COLORS["error"]), ephemeral=True); return
        cfg = get_guild("automod", interaction.guild_id); cfg.setdefault("banned_words", []); w = word.lower().strip()
        if w in cfg["banned_words"]:
            await interaction.response.send_message(embed=make_embed(description=f"⚠️ `{word}` is already banned.", color=COLORS["warning"]), ephemeral=True); return
        cfg["banned_words"].append(w); set_guild("automod", interaction.guild_id, cfg)
        await interaction.response.send_message(embed=make_embed(title="🚫 Banned Word Added",
            description=f"**Word:** `{word}`\n\n🔇 Timeout · 🏷️ Blacklisted role · 🗑️ Message deleted\n\n📋 **Total:** {len(cfg['banned_words'])}",
            color=COLORS["error"]))

    @app_commands.command(name="automodremove", description="✅ Remove a banned word")
    @app_commands.describe(word="Word to un-ban")
    async def automodremove(self, interaction: discord.Interaction, word: str):
        if not (is_staff(interaction.user) or interaction.user.id == OWNER_ID):
            await interaction.response.send_message(embed=make_embed(description="🔒 **Staff only!**", color=COLORS["error"]), ephemeral=True); return
        cfg = get_guild("automod", interaction.guild_id); w = word.lower().strip()
        if w not in cfg.get("banned_words", []):
            await interaction.response.send_message(embed=make_embed(description=f"❌ `{word}` is not banned.", color=COLORS["error"]), ephemeral=True); return
        cfg["banned_words"].remove(w); set_guild("automod", interaction.guild_id, cfg)
        await interaction.response.send_message(embed=make_embed(description=f"✅ `{word}` removed from banned words.", color=COLORS["success"]))

    @app_commands.command(name="automodwhitelist", description="🛡️ Whitelist a role from automod")
    @app_commands.describe(role="Role to whitelist")
    async def automodwhitelist(self, interaction: discord.Interaction, role: discord.Role):
        if not (is_staff(interaction.user) or interaction.user.id == OWNER_ID):
            await interaction.response.send_message(embed=make_embed(description="🔒 **Staff only!**", color=COLORS["error"]), ephemeral=True); return
        cfg = get_guild("automod", interaction.guild_id); cfg.setdefault("whitelist_roles", [])
        if role.id in cfg["whitelist_roles"]:
            await interaction.response.send_message(embed=make_embed(description=f"⚠️ {role.mention} already whitelisted.", color=COLORS["warning"]), ephemeral=True); return
        cfg["whitelist_roles"].append(role.id); set_guild("automod", interaction.guild_id, cfg)
        await interaction.response.send_message(embed=make_embed(title="🛡️ Role Whitelisted",
            description=f"**Role:** {role.mention}\nMembers with this role bypass AutoMod.\n\n📋 **Total whitelisted:** {len(cfg['whitelist_roles'])}",
            color=COLORS["success"]))

    @app_commands.command(name="automodunwhitelist", description="🔓 Remove a role from the whitelist")
    @app_commands.describe(role="Role to remove")
    async def automodunwhitelist(self, interaction: discord.Interaction, role: discord.Role):
        if not (is_staff(interaction.user) or interaction.user.id == OWNER_ID):
            await interaction.response.send_message(embed=make_embed(description="🔒 **Staff only!**", color=COLORS["error"]), ephemeral=True); return
        cfg = get_guild("automod", interaction.guild_id)
        if role.id not in cfg.get("whitelist_roles", []):
            await interaction.response.send_message(embed=make_embed(description=f"❌ {role.mention} is not whitelisted.", color=COLORS["error"]), ephemeral=True); return
        cfg["whitelist_roles"].remove(role.id); set_guild("automod", interaction.guild_id, cfg)
        await interaction.response.send_message(embed=make_embed(description=f"✅ {role.mention} removed from whitelist.", color=COLORS["success"]))

    @app_commands.command(name="automodlist", description="📋 View banned words and whitelisted roles")
    async def automodlist(self, interaction: discord.Interaction):
        if not (is_staff(interaction.user) or interaction.user.id == OWNER_ID):
            await interaction.response.send_message(embed=make_embed(description="🔒 **Staff only!**", color=COLORS["error"]), ephemeral=True); return
        cfg = get_guild("automod", interaction.guild_id)
        banned = cfg.get("banned_words", []); wl = cfg.get("whitelist_roles", [])
        e = discord.Embed(title="🚫 AutoMod Configuration", color=COLORS["primary"])
        e.add_field(name=f"🚫 Banned Words ({len(banned)})",
            value="\n".join(f"• `{w}`" for w in banned[:25]) + ("\n*...and more*" if len(banned)>25 else "") if banned else "*None*",
            inline=False)
        if wl:
            mentions = [r.mention if (r:=interaction.guild.get_role(rid)) else f"`{rid}`" for rid in wl]
            e.add_field(name=f"🛡️ Whitelisted Roles ({len(wl)})", value="\n".join(mentions), inline=False)
        else:
            e.add_field(name="🛡️ Whitelisted Roles", value="*None*", inline=False)
        e.set_footer(text=f"Requested by {interaction.user}")
        await interaction.response.send_message(embed=e, ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild or message.author.id == OWNER_ID: return
        cfg = get_guild("automod", message.guild.id); banned_words = cfg.get("banned_words", [])
        if not banned_words: return
        wl_roles = cfg.get("whitelist_roles", [])
        if any(r.id in wl_roles for r in message.author.roles): return
        content_lower = message.content.lower()
        triggered = next((w for w in banned_words if w in content_lower), None)
        if not triggered: return
        try: await message.delete()
        except: pass
        try: await message.author.timeout(discord.utils.utcnow() + timedelta(minutes=10), reason=f"AutoMod: '{triggered}'")
        except: pass
        blacklisted = discord.utils.get(message.guild.roles, name="Blacklisted")
        if not blacklisted:
            try: blacklisted = await message.guild.create_role(name="Blacklisted", color=discord.Color.dark_red(), reason="AutoMod auto-created")
            except: blacklisted = None
        if blacklisted:
            try: await message.author.add_roles(blacklisted, reason=f"AutoMod: '{triggered}'")
            except: pass
        try:
            await message.channel.send(embed=make_embed(title="🚫 AutoMod — Message Removed",
                description=f"**{message.author.mention}'s** message was removed.\n🔇 Timed out 10 min · 🏷️ Blacklisted · 🗑️ Deleted\n*Please follow the server rules!*",
                color=COLORS["error"]), delete_after=8)
        except: pass
        try:
            await message.author.send(embed=make_embed(title="🚫 You Triggered AutoMod",
                description=f"**Server:** {message.guild.name}\n\nYour message was removed for a **banned word**.\n🔇 Timed out **10 minutes** · 🏷️ Blacklisted role assigned",
                color=COLORS["error"]))
        except: pass

# ================================================================
#  GAMES COG
# ================================================================
RPS_EMOJIS = {"rock":"🪨","paper":"📄","scissors":"✂️"}
RPS_BEATS  = {"rock":"scissors","paper":"rock","scissors":"paper"}

class RPSView(ui.View):
    def __init__(self, author):
        super().__init__(timeout=30); self.author = author
    async def interaction_check(self, interaction):
        if interaction.user.id != self.author.id:
            await interaction.response.send_message("❌ This isn't your game!", ephemeral=True); return False
        return True
    async def _play(self, interaction, choice):
        bc = random.choice(["rock","paper","scissors"]); pe,be = RPS_EMOJIS[choice],RPS_EMOJIS[bc]
        if choice==bc: result,color="🤝 It's a Tie!",COLORS["info"]
        elif RPS_BEATS[choice]==bc: result,color="🎉 You Win!",COLORS["success"]
        else: result,color="😈 Bot Wins!",COLORS["error"]
        e = discord.Embed(title="🪨📄✂️ Rock Paper Scissors",
            description=f"**You:** {pe} `{choice.capitalize()}`\n**Bot:** {be} `{bc.capitalize()}`\n\n**{result}**",color=color)
        for child in self.children: child.disabled=True
        await interaction.response.edit_message(embed=e,view=self); self.stop()
    @ui.button(label="🪨 Rock",style=discord.ButtonStyle.secondary)
    async def rock(self,i,b): await self._play(i,"rock")
    @ui.button(label="📄 Paper",style=discord.ButtonStyle.secondary)
    async def paper(self,i,b): await self._play(i,"paper")
    @ui.button(label="✂️ Scissors",style=discord.ButtonStyle.secondary)
    async def scissors(self,i,b): await self._play(i,"scissors")

class TTTButton(ui.Button):
    def __init__(self,row,col):
        super().__init__(style=discord.ButtonStyle.secondary,label="\u200b",row=row)
        self.row_idx=row; self.col_idx=col
    async def callback(self,interaction):
        view=self.view
        if interaction.user!=view.current_player():
            await interaction.response.send_message("❌ Not your turn!",ephemeral=True); return
        if self.label!="\u200b":
            await interaction.response.send_message("❌ Taken!",ephemeral=True); return
        symbol="❌" if view.turn==0 else "⭕"
        self.label=symbol; self.style=discord.ButtonStyle.danger if view.turn==0 else discord.ButtonStyle.primary
        self.disabled=True; view.board[self.row_idx][self.col_idx]=symbol
        if view.check_winner():
            view.disable_all()
            await interaction.response.edit_message(embed=make_embed(title="🎮 Tic-Tac-Toe",
                description=f"🏆 **{view.current_player().display_name}** wins!",color=COLORS["success"]),view=view)
            view.stop(); return
        if all(view.board[r][c]!="" for r in range(3) for c in range(3)):
            view.disable_all()
            await interaction.response.edit_message(embed=make_embed(title="🎮 Tic-Tac-Toe",description="🤝 Draw!",color=COLORS["info"]),view=view)
            view.stop(); return
        view.turn^=1; nxt=view.current_player(); sym="❌" if view.turn==0 else "⭕"
        await interaction.response.edit_message(embed=make_embed(title="🎮 Tic-Tac-Toe",
            description=f"**{nxt.display_name}'s turn** — {sym}",color=COLORS["primary"]),view=view)

class TTTView(ui.View):
    def __init__(self,p1,p2):
        super().__init__(timeout=120); self.players=[p1,p2]; self.turn=0
        self.board=[["","",""] for _ in range(3)]
        for r in range(3):
            for c in range(3): self.add_item(TTTButton(r,c))
    def current_player(self): return self.players[self.turn]
    def check_winner(self):
        b=self.board
        lines=[*b,*[[b[r][c] for r in range(3)] for c in range(3)],[b[0][0],b[1][1],b[2][2]],[b[0][2],b[1][1],b[2][0]]]
        for ln in lines:
            if ln[0] and ln[0]==ln[1]==ln[2]: return ln[0]
        return None
    def disable_all(self):
        for child in self.children: child.disabled=True

C4_ROWS,C4_COLS=6,7; C4_EMPTY="⬛"; C4_TOKENS=["🔴","🟡"]

class Connect4View(ui.View):
    def __init__(self,p1,p2):
        super().__init__(timeout=180); self.players=[p1,p2]; self.turn=0
        self.board=[[C4_EMPTY]*C4_COLS for _ in range(C4_ROWS)]
        for col in range(C4_COLS):
            btn=ui.Button(label=str(col+1),style=discord.ButtonStyle.primary,row=0 if col<4 else 1)
            btn.callback=self._make_callback(col); self.add_item(btn)
    def _make_callback(self,col):
        async def callback(interaction):
            if interaction.user!=self.players[self.turn]:
                await interaction.response.send_message("❌ Not your turn!",ephemeral=True); return
            row=self._drop(col)
            if row is None:
                await interaction.response.send_message("❌ Column full!",ephemeral=True); return
            self.board[row][col]=C4_TOKENS[self.turn]; wt=self._check_win(row,col); bs=self._render()
            if wt:
                for child in self.children: child.disabled=True
                await interaction.response.edit_message(embed=make_embed(title="🔴🟡 Connect 4",
                    description=f"{bs}\n\n🏆 **{self.players[self.turn].display_name}** wins!",color=COLORS["success"]),view=self)
                self.stop(); return
            if all(self.board[0][c]!=C4_EMPTY for c in range(C4_COLS)):
                for child in self.children: child.disabled=True
                await interaction.response.edit_message(embed=make_embed(title="🔴🟡 Connect 4",
                    description=f"{bs}\n\n🤝 Draw!",color=COLORS["info"]),view=self); self.stop(); return
            self.turn^=1
            await interaction.response.edit_message(embed=make_embed(title="🔴🟡 Connect 4",
                description=f"{bs}\n\n{C4_TOKENS[self.turn]} **{self.players[self.turn].display_name}'s turn**",
                color=COLORS["primary"]),view=self)
        return callback
    def _drop(self,col):
        for row in range(C4_ROWS-1,-1,-1):
            if self.board[row][col]==C4_EMPTY: return row
        return None
    def _render(self):
        return "".join(f"`{c+1}`" for c in range(C4_COLS))+"\n"+"\n".join("".join(self.board[r]) for r in range(C4_ROWS))
    def _check_win(self,r,c):
        token=self.board[r][c]
        def count(dr,dc):
            n,nr,nc=0,r+dr,c+dc
            while 0<=nr<C4_ROWS and 0<=nc<C4_COLS and self.board[nr][nc]==token: n+=1;nr+=dr;nc+=dc
            return n
        for dr,dc in [(0,1),(1,0),(1,1),(1,-1)]:
            if count(dr,dc)+count(-dr,-dc)>=3: return token
        return None

class WordChainGame:
    def __init__(self,cid): self.channel_id=cid; self.players=[]; self.used_words=set(); self.current_word=None; self.turn_idx=0; self.active=False
    def current_player(self): return self.players[self.turn_idx%len(self.players)]
    def next_turn(self): self.turn_idx+=1

class WordChainJoinView(ui.View):
    def __init__(self,game,starter):
        super().__init__(timeout=30); game.players.append(starter); self._game=game
    @ui.button(label="✋ Join Game",style=discord.ButtonStyle.success)
    async def join(self,interaction,button):
        if interaction.user in self._game.players:
            await interaction.response.send_message("✅ Already joined!",ephemeral=True); return
        self._game.players.append(interaction.user)
        await interaction.response.send_message(f"✅ **{interaction.user.display_name}** joined! ({len(self._game.players)} players)")

class Games(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.wordchain_games={}; self.active_games=set()

    @commands.hybrid_command(name="rps",description="🪨📄✂️ Play Rock Paper Scissors!")
    @commands.cooldown(1,5,commands.BucketType.user)
    async def rps(self,ctx):
        view=RPSView(ctx.author)
        await ctx.send(embed=make_embed(title="🪨📄✂️ Rock Paper Scissors",
            description=f"**{ctx.author.display_name}** — Choose! *(30s)*",
            color=COLORS["primary"],thumbnail=str(ctx.author.display_avatar.url)),view=view)

    @commands.hybrid_command(name="trivia",description="🧠 Answer a random trivia question!")
    @commands.cooldown(1,10,commands.BucketType.user)
    async def trivia(self,ctx):
        await ctx.defer()
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get("https://opentdb.com/api.php?amount=1&type=multiple",
                    timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    data=await resp.json(content_type=None)
            except:
                await ctx.send(embed=make_embed(description="❌ Trivia API unavailable. Try again!",color=COLORS["error"])); return
        if data.get("response_code",1)!=0 or not data.get("results"):
            await ctx.send(embed=make_embed(description="⚠️ API rate limited. Try in a few seconds!",color=COLORS["warning"])); return
        q=data["results"][0]; question=html.unescape(q["question"]); correct=html.unescape(q["correct_answer"])
        incorrect=[html.unescape(a) for a in q["incorrect_answers"]]; answers=incorrect+[correct]; random.shuffle(answers)
        letters=["🅰️","🅱️","🇨","🇩"]; letter_map={"A":"🅰️","B":"🅱️","C":"🇨","D":"🇩"}
        opts="\n".join(f"{letters[i]} {answers[i]}" for i in range(len(answers)))
        diff_colors={"easy":COLORS["success"],"medium":COLORS["warning"],"hard":COLORS["error"]}
        await ctx.send(embed=discord.Embed(title=f"🧠 Trivia — {q['category']}",
            description=f"**{question}**\n\n{opts}\n\n*20 seconds to answer!*",
            color=diff_colors.get(q["difficulty"],COLORS["primary"])).set_footer(text="Type A, B, C or D"))
        valid={letters[i]:answers[i] for i in range(len(answers))}
        def check(m): return m.author==ctx.author and m.channel==ctx.channel and m.content.upper().strip() in ["🅰️","🅱️","🇨","🇩","A","B","C","D"]
        try:
            reply=await self.bot.wait_for("message",check=check,timeout=20); ans=reply.content.upper().strip()
            if ans in letter_map: ans=letter_map[ans]
            chosen=valid.get(ans,"")
            if chosen==correct: result_e=make_embed(title="✅ Correct!",description=f"🎉 **{ctx.author.display_name}** got it!\n**Answer:** {correct}",color=COLORS["success"])
            else: result_e=make_embed(title="❌ Wrong!",description=f"Chose `{chosen or ans}`\n**Correct:** {correct}",color=COLORS["error"])
        except asyncio.TimeoutError:
            result_e=make_embed(title="⏰ Time's Up!",description=f"**Correct Answer:** {correct}",color=COLORS["warning"])
        await ctx.send(embed=result_e)

    @commands.hybrid_command(name="tictactoe",description="❌⭕ Challenge someone to Tic-Tac-Toe!")
    @app_commands.describe(opponent="Your opponent")
    @commands.cooldown(1,10,commands.BucketType.channel)
    async def tictactoe(self,ctx,opponent:discord.Member):
        if opponent.bot or opponent==ctx.author:
            await ctx.send(embed=make_embed(description="❌ Invalid opponent!",color=COLORS["error"])); return
        await ctx.send(embed=make_embed(title="🎮 Tic-Tac-Toe",
            description=f"❌ **{ctx.author.display_name}** vs ⭕ **{opponent.display_name}**\n\n**{ctx.author.display_name}'s turn** — ❌",
            color=COLORS["primary"]),view=TTTView(ctx.author,opponent))

    @commands.hybrid_command(name="connect4",description="🔴🟡 Challenge someone to Connect 4!")
    @app_commands.describe(opponent="Your opponent")
    @commands.cooldown(1,10,commands.BucketType.channel)
    async def connect4(self,ctx,opponent:discord.Member):
        if opponent.bot or opponent==ctx.author:
            await ctx.send(embed=make_embed(description="❌ Invalid opponent!",color=COLORS["error"])); return
        game=Connect4View(ctx.author,opponent)
        await ctx.send(embed=make_embed(title="🔴🟡 Connect 4",
            description=f"🔴 **{ctx.author.display_name}** vs 🟡 **{opponent.display_name}**\n\n{game._render()}\n\n🔴 **{ctx.author.display_name}'s turn**\n*Row 1 = cols 1–4 · Row 2 = cols 5–7*",
            color=COLORS["primary"]),view=game)

    @commands.hybrid_command(name="wordchain",description="🔤 Start a multiplayer word chain!")
    @commands.cooldown(1,10,commands.BucketType.channel)
    async def wordchain(self,ctx):
        cid=ctx.channel.id
        if cid in self.wordchain_games and self.wordchain_games[cid].active:
            await ctx.send(embed=make_embed(description="❌ A game is already running!",color=COLORS["error"])); return
        game=WordChainGame(cid); self.wordchain_games[cid]=game
        join_view=WordChainJoinView(game,ctx.author)
        await ctx.send(embed=make_embed(title="🔤 Word Chain — Join Phase",
            description=f"Each player says a word starting with the **last letter** of the previous word!\n\n**{ctx.author.display_name}** joined!\n\nClick **Join Game**! Starts in **30 seconds**.",
            color=COLORS["purple"]),view=join_view)
        await asyncio.sleep(30); join_view.stop()
        if len(game.players)<2:
            self.wordchain_games.pop(cid,None)
            await ctx.send(embed=make_embed(description="❌ Not enough players (need 2+). Cancelled.",color=COLORS["error"])); return
        starter=random.choice(["apple","orange","banana","grape","melon","tiger","eagle","shark","wolf","bear"])
        game.current_word=starter; game.used_words.add(starter); game.active=True
        names=", ".join(m.display_name for m in game.players)
        await ctx.send(embed=make_embed(title="🔤 Word Chain — Started!",
            description=f"**Players:** {names}\n\n🎯 **Starting word:** `{starter}`\n🔤 **Next starts with:** `{starter[-1].upper()}`\n\n👉 {game.current_player().mention} — you're first! *(30s)*",
            color=COLORS["success"]))
        try:
            while game.active and len(game.players)>=2:
                current=game.current_player(); last_letter=game.current_word[-1].lower()
                def wc_check(m,_cur=current): return m.author==_cur and m.channel==ctx.channel and m.content.isalpha()
                try:
                    reply=await self.bot.wait_for("message",check=wc_check,timeout=30)
                    word=reply.content.lower().strip()
                    if not word.startswith(last_letter):
                        await ctx.send(embed=make_embed(description=f"❌ **{current.display_name}** — `{word}` doesn't start with `{last_letter.upper()}`! 💀 Eliminated!",color=COLORS["error"]))
                        game.players.remove(current)
                    elif word in game.used_words:
                        await ctx.send(embed=make_embed(description=f"❌ **{current.display_name}** — `{word}` already used! 💀 Eliminated!",color=COLORS["error"]))
                        game.players.remove(current)
                    else:
                        game.used_words.add(word); game.current_word=word; game.next_turn(); nxt=game.current_player()
                        await ctx.send(embed=make_embed(description=f"✅ **{current.display_name}** said `{word}`!\n🔤 Next: **`{word[-1].upper()}`**\n👉 {nxt.mention} *(30s)*",color=COLORS["primary"]))
                except asyncio.TimeoutError:
                    await ctx.send(embed=make_embed(description=f"⏰ **{current.display_name}** too slow! 💀 Eliminated!",color=COLORS["warning"]))
                    game.players.remove(current)
            game.active=False; winner=game.players[0] if game.players else None
            if winner:
                await ctx.send(embed=make_embed(title="🏆 Word Chain — Winner!",
                    description=f"🎉 **{winner.display_name}** wins!\n🔤 {len(game.used_words)} words used!",color=COLORS["gold"]))
        finally: self.wordchain_games.pop(cid,None)

# ================================================================
#  PARTY GAMES COG
# ================================================================
WYR_QUESTIONS=[
    ("Have the ability to fly ✈️","Have the ability to be invisible 👻"),
    ("Always speak your mind 🗣️","Never be able to speak again 🤫"),
    ("Live in a world with no music 🎵","Live in a world with no internet 🌐"),
    ("Have unlimited money 💰","Have unlimited time ⏰"),
    ("Be famous but poor 🌟","Be rich but unknown 💎"),
    ("Fight 100 duck-sized horses 🐴","Fight 1 horse-sized duck 🦆"),
    ("Always be cold ❄️","Always be hot 🔥"),
    ("Speak all languages fluently 🌍","Play all instruments perfectly 🎸"),
    ("Lose all your memories 🧠","Lose all your friends 👥"),
    ("Go to the past ⏪","Go to the future ⏩"),
]
HANGMAN_WORDS=["python","discord","programming","keyboard","monitor","internet","gaming","adventure",
    "treasure","mystery","elephant","universe","chocolate","pineapple","dinosaur","butterfly","lightning","mountain"]
MEMORY_EMOJIS=["🍎","🍊","🍇","🍓","🍒","🍋","🍉","🥝","🐶","🐱","🐭","🐹","🐸","🦊","🐻","🐼"]
HANGMAN_STAGES=["```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```",
    "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```"]
FAST_TYPE_SENTENCES=["The quick brown fox jumps over the lazy dog",
    "Pack my box with five dozen liquor jugs","Gaming is not just a hobby it is a lifestyle",
    "Discord bots make server management so much easier","The five boxing wizards jump quickly",
    "Coding every day will make you a better programmer"]

class WYRView(ui.View):
    def __init__(self): super().__init__(timeout=30); self.votes_a=[]; self.votes_b=[]
    @ui.button(label="🅰️ Option A",style=discord.ButtonStyle.primary,row=0)
    async def vote_a(self,interaction,button):
        uid=interaction.user.id
        if uid in self.votes_a: await interaction.response.send_message("✅ Already voted A!",ephemeral=True); return
        if uid in self.votes_b: self.votes_b.remove(uid)
        self.votes_a.append(uid); await interaction.response.send_message("✅ Voted **Option A**!",ephemeral=True)
    @ui.button(label="🅱️ Option B",style=discord.ButtonStyle.danger,row=0)
    async def vote_b(self,interaction,button):
        uid=interaction.user.id
        if uid in self.votes_b: await interaction.response.send_message("✅ Already voted B!",ephemeral=True); return
        if uid in self.votes_a: self.votes_a.remove(uid)
        self.votes_b.append(uid); await interaction.response.send_message("✅ Voted **Option B**!",ephemeral=True)

class MafiaJoinView(ui.View):
    def __init__(self): super().__init__(timeout=60); self.players=[]
    @ui.button(label="🎭 Join Mafia",style=discord.ButtonStyle.success)
    async def join(self,interaction,button):
        if interaction.user in self.players: await interaction.response.send_message("✅ Already in!",ephemeral=True); return
        self.players.append(interaction.user)
        await interaction.response.send_message(f"🎭 **{interaction.user.display_name}** joined! ({len(self.players)} players)")
    @ui.button(label="🚀 Start Game",style=discord.ButtonStyle.danger)
    async def start(self,interaction,button):
        if len(self.players)<4: await interaction.response.send_message("❌ Need 4+ players!",ephemeral=True); return
        for child in self.children: child.disabled=True
        await interaction.response.edit_message(view=self); self.stop()

class MafiaVoteView(ui.View):
    def __init__(self,players):
        super().__init__(timeout=60); self.votes={}
        for p in players:
            btn=ui.Button(label=p.display_name[:20],style=discord.ButtonStyle.secondary,emoji="🗳️")
            btn.callback=self._make_vote(p.id,p.display_name); self.add_item(btn)
    def _make_vote(self,tid,name):
        async def cb(interaction):
            self.votes[interaction.user.id]=tid
            await interaction.response.send_message(f"🗳️ Voted to eliminate **{name}**!",ephemeral=True)
        return cb

class PartyGames(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.active_games=set()
    def _lock(self,cid):
        if cid in self.active_games: return False
        self.active_games.add(cid); return True
    def _unlock(self,cid): self.active_games.discard(cid)

    @commands.hybrid_command(name="wouldyourather",description="🤔 Vote on a Would You Rather question!")
    @commands.cooldown(1,10,commands.BucketType.channel)
    async def would_you_rather(self,ctx):
        opt_a,opt_b=random.choice(WYR_QUESTIONS); view=WYRView()
        e=discord.Embed(title="🤔 Would You Rather…",color=COLORS["pink"])
        e.add_field(name="🅰️ Option A",value=opt_a,inline=True); e.add_field(name="🅱️ Option B",value=opt_b,inline=True)
        e.set_footer(text="Vote within 30 seconds!"); msg=await ctx.send(embed=e,view=view)
        await asyncio.sleep(30); view.stop()
        for child in view.children: child.disabled=True
        total=len(view.votes_a)+len(view.votes_b); pct_a=round(len(view.votes_a)/total*100) if total else 0; pct_b=round(len(view.votes_b)/total*100) if total else 0
        re=discord.Embed(title="🤔 Would You Rather — Results!",color=COLORS["gold"])
        re.add_field(name=f"🅰️ {opt_a}",value=f"**{pct_a}%** — {len(view.votes_a)} vote(s)",inline=True)
        re.add_field(name=f"🅱️ {opt_b}",value=f"**{pct_b}%** — {len(view.votes_b)} vote(s)",inline=True)
        re.set_footer(text=f"Total votes: {total}")
        try: await msg.edit(embed=re,view=view)
        except: await ctx.send(embed=re)

    @commands.hybrid_command(name="hangman",description="🪢 Play multiplayer hangman!")
    @commands.cooldown(1,10,commands.BucketType.channel)
    async def hangman(self,ctx):
        cid=ctx.channel.id
        if not self._lock(cid): await ctx.send(embed=make_embed(description="❌ A game is already running!",color=COLORS["error"])); return
        try:
            word=random.choice(HANGMAN_WORDS); guessed=set(); attempts=0; max_att=6
            def display(): return " ".join(l if l in guessed else "_" for l in word)
            msg=await ctx.send(embed=discord.Embed(title="🪢 Hangman — Guess the Word!",
                description=f"{HANGMAN_STAGES[0]}\n**Word:** `{display()}`\n**Guessed:** None\n**Attempts left:** {max_att} ❤️",
                color=COLORS["purple"]))
            while attempts<max_att:
                if "_" not in display(): break
                def check(m): return m.channel==ctx.channel and not m.author.bot and len(m.content)==1 and m.content.isalpha()
                try:
                    reply=await self.bot.wait_for("message",check=check,timeout=30); letter=reply.content.lower()
                    if letter in guessed:
                        await ctx.send(embed=make_embed(description=f"🔁 `{letter.upper()}` already guessed!",color=COLORS["warning"]),delete_after=3); continue
                    guessed.add(letter)
                    if letter in word: title=f"✅ `{letter.upper()}` is in the word!"; color=COLORS["success"]
                    else: attempts+=1; title=f"❌ `{letter.upper()}` not in the word!"; color=COLORS["error"]
                    won="_" not in display()
                    e=discord.Embed(title="🪢 Hangman"+(" — YOU WIN! 🎉" if won else (" — GAME OVER 💀" if attempts>=max_att else "")),
                        description=f"{HANGMAN_STAGES[min(attempts,6)]}\n**Word:** `{display()}`\n**Guessed:** {', '.join(sorted(guessed)).upper() or 'None'}\n**Attempts left:** {max_att-attempts} ❤️\n\n*{title}*",
                        color=COLORS["success"] if won else (COLORS["error"] if attempts>=max_att else color))
                    await msg.edit(embed=e)
                    if won or attempts>=max_att: break
                except asyncio.TimeoutError:
                    await ctx.send(embed=make_embed(description=f"⏰ Time's up! Word was **`{word}`**!",color=COLORS["warning"])); return
            if "_" not in display(): await ctx.send(embed=make_embed(title="🎉 Hangman Won!",description=f"Word was **`{word}`**! 🏆",color=COLORS["success"]))
            else: await ctx.send(embed=make_embed(title="💀 Hangman Over!",description=f"Word was **`{word}`**.",color=COLORS["error"]))
        finally: self._unlock(cid)

    @commands.hybrid_command(name="fasttype",description="⌨️ Race to type the sentence fastest!")
    @commands.cooldown(1,15,commands.BucketType.channel)
    async def fasttype(self,ctx):
        cid=ctx.channel.id
        if not self._lock(cid): await ctx.send(embed=make_embed(description="❌ A game is already running!",color=COLORS["error"])); return
        try:
            sentence=random.choice(FAST_TYPE_SENTENCES)
            await ctx.send(embed=make_embed(title="⌨️ Fast Type — Get Ready!",description="Type the sentence as fast as you can!\nStarts in **3 seconds…**",color=COLORS["info"]))
            await asyncio.sleep(3)
            await ctx.send(embed=discord.Embed(title="⌨️ GO GO GO!",description=f"```{sentence}```",color=COLORS["success"]).set_footer(text="First to type it correctly wins!"))
            start=time.time(); winners=[]
            def check(m): return m.channel==ctx.channel and not m.author.bot
            try:
                deadline=asyncio.get_event_loop().time()+35
                while True:
                    remaining=deadline-asyncio.get_event_loop().time()
                    if remaining<=0: break
                    reply=await self.bot.wait_for("message",check=check,timeout=min(remaining,35))
                    if reply.content.lower().strip()==sentence.lower().strip():
                        elapsed=round(time.time()-start,2); winners.append((reply.author,elapsed))
                        if len(winners)==1:
                            await ctx.send(embed=make_embed(title="🏆 First Place!",description=f"⚡ **{reply.author.mention}** wins in **{elapsed}s**!\n*Waiting 5s for others…*",color=COLORS["gold"]))
                            await asyncio.sleep(5); break
            except asyncio.TimeoutError: pass
            if not winners:
                await ctx.send(embed=make_embed(description="😮 Nobody typed it correctly!",color=COLORS["error"])); return
            medals=["🥇","🥈","🥉"]
            lines="\n".join(f"{medals[i] if i<3 else f'{i+1}.'} **{w[0].display_name}** — {w[1]}s" for i,w in enumerate(winners))
            await ctx.send(embed=make_embed(title="⌨️ Fast Type — Results!",description=f"```{sentence}```\n\n{lines}",color=COLORS["primary"]))
        finally: self._unlock(cid)

    @commands.hybrid_command(name="memorymatch",description="🧩 Multiplayer emoji memory matching!")
    @commands.cooldown(1,15,commands.BucketType.channel)
    async def memorymatch(self,ctx):
        cid=ctx.channel.id
        if not self._lock(cid): await ctx.send(embed=make_embed(description="❌ A game is already running!",color=COLORS["error"])); return
        try:
            pairs=random.sample(MEMORY_EMOJIS,8); cards=pairs*2; random.shuffle(cards)
            revealed=[False]*16; matched=[False]*16; scores={}
            def render():
                rows=[]
                for r in range(4):
                    row_str=""
                    for c in range(4):
                        idx=r*4+c
                        row_str+="✅ " if matched[idx] else (f"{cards[idx]} " if revealed[idx] else f"`{str(idx+1).zfill(2)}` ")
                    rows.append(row_str)
                return "\n".join(rows)
            msg=await ctx.send(embed=discord.Embed(title="🧩 Memory Match",
                description=f"{render()}\n\n**Type two numbers** (e.g. `3 7`) to reveal cards!\nMatch all 8 pairs to win! *(60s per turn)*",
                color=COLORS["purple"]))
            def check(m): return m.channel==ctx.channel and not m.author.bot
            matched_pairs=0
            while matched_pairs<8:
                try:
                    reply=await self.bot.wait_for("message",check=check,timeout=60)
                    parts=reply.content.strip().split()
                    if len(parts)!=2: continue
                    try: a,b=int(parts[0])-1,int(parts[1])-1
                    except ValueError: continue
                    if not(0<=a<16 and 0<=b<16) or a==b: continue
                    if matched[a] or matched[b]:
                        await ctx.send(embed=make_embed(description="❌ Already matched!",color=COLORS["error"]),delete_after=3); continue
                    revealed[a]=revealed[b]=True
                    await msg.edit(embed=discord.Embed(title="🧩 Memory Match",
                        description=f"{render()}\n\n🔍 **{reply.author.display_name}** revealed `{a+1}` and `{b+1}`!",color=COLORS["info"]))
                    await asyncio.sleep(2)
                    if cards[a]==cards[b]:
                        matched[a]=matched[b]=True; matched_pairs+=1; uid=reply.author.id; scores[uid]=scores.get(uid,0)+1
                        await msg.edit(embed=discord.Embed(title="🧩 Memory Match",
                            description=f"{render()}\n\n✅ **{reply.author.display_name}** matched **{cards[a]}**! (Score: {scores[uid]})\nPairs left: {8-matched_pairs}",
                            color=COLORS["success"]))
                    else:
                        revealed[a]=revealed[b]=False
                        await msg.edit(embed=discord.Embed(title="🧩 Memory Match",description=f"{render()}\n\n❌ **No match!** Try again.",color=COLORS["error"]))
                except asyncio.TimeoutError:
                    await ctx.send(embed=make_embed(description="⏰ Game timed out!",color=COLORS["warning"])); return
            if scores:
                winner_id=max(scores,key=scores.get); winner=ctx.guild.get_member(winner_id) or ctx.author
                board_str="\n".join(f"**{ctx.guild.get_member(uid).display_name if ctx.guild.get_member(uid) else uid}** — {s} pairs" for uid,s in sorted(scores.items(),key=lambda x:-x[1]))
                await ctx.send(embed=make_embed(title="🧩 Memory Match — Game Over!",description=f"🏆 **{winner.display_name}** wins!\n\n{board_str}",color=COLORS["gold"]))
        finally: self._unlock(cid)

    @commands.hybrid_command(name="mafia",description="🎭 Social deduction — find the hidden Mafia!")
    @commands.cooldown(1,30,commands.BucketType.channel)
    async def mafia(self,ctx):
        cid=ctx.channel.id
        if not self._lock(cid): await ctx.send(embed=make_embed(description="❌ A game is already running!",color=COLORS["error"])); return
        try:
            view=MafiaJoinView()
            await ctx.send(embed=discord.Embed(title="🎭 Mafia — Join Phase!",
                description="🔪 One player is secretly the **Mafia**.\n🕊️ The rest are **Civilians** — vote to eliminate the Mafia!\n\nClick **Join Mafia** *(min 4)* then **Start Game**.",
                color=COLORS["dark"]).set_footer(text="60 seconds to join!"),view=view)
            try: await asyncio.wait_for(view.wait(),timeout=60)
            except asyncio.TimeoutError: pass
            players=view.players
            if len(players)<4:
                await ctx.send(embed=make_embed(description="❌ Not enough players (need 4+).",color=COLORS["error"])); return
            mafia_count=max(1,len(players)//4); mafia_members=random.sample(players,mafia_count)
            for p in players:
                role_text="🔪 **MAFIA**" if p in mafia_members else "🕊️ **CIVILIAN**"
                hint="Stay hidden and mislead the civilians!" if p in mafia_members else "Find and vote out the Mafia!"
                try:
                    await p.send(embed=make_embed(title="🎭 Your Mafia Role",
                        description=f"**Your Role:** {role_text}\n\n{hint}",
                        color=COLORS["error"] if p in mafia_members else COLORS["info"]))
                except: pass
            names=", ".join(p.display_name for p in players)
            await ctx.send(embed=discord.Embed(title="🎭 Mafia — Game Started!",
                description=f"**Players ({len(players)}):** {names}\n\n📬 Check your DMs!\n💬 Discuss then vote!",color=COLORS["dark"]))
            eliminated=[]
            while True:
                alive=[p for p in players if p not in eliminated]
                mafia_alive=[p for p in mafia_members if p not in eliminated]
                civilians_alive=[p for p in alive if p not in mafia_members]
                if not mafia_alive:
                    await ctx.send(embed=make_embed(title="🎭 Civilians Win! 🕊️",
                        description=f"🎉 Mafia eliminated!\n🔪 **Mafia was:** {', '.join(m.display_name for m in mafia_members)}",color=COLORS["success"])); break
                if len(mafia_alive)>=len(civilians_alive):
                    await ctx.send(embed=make_embed(title="🎭 Mafia Wins! 🔪",
                        description=f"😈 Mafia outnumbers!\n🔪 **Mafia was:** {', '.join(m.display_name for m in mafia_members)}",color=COLORS["error"])); break
                vote_view=MafiaVoteView(alive)
                await ctx.send(embed=discord.Embed(title="🗳️ Voting Phase",
                    description=f"**Alive:** {', '.join(p.display_name for p in alive)}\n\n🗳️ Vote! *(60s)*",color=COLORS["warning"]))
                vote_msg=await ctx.send(view=vote_view); await asyncio.sleep(60)
                vote_view.stop()
                for child in vote_view.children: child.disabled=True
                try: await vote_msg.edit(view=vote_view)
                except: pass
                tally={}
                for _,target in vote_view.votes.items(): tally[target]=tally.get(target,0)+1
                if not tally: await ctx.send(embed=make_embed(description="🤷 No votes! Skipping.",color=COLORS["info"])); continue
                top_id=max(tally,key=tally.get); victim=next((p for p in alive if p.id==top_id),None)
                if victim:
                    eliminated.append(victim); is_m=victim in mafia_members
                    await ctx.send(embed=make_embed(title="☠️ Player Eliminated!",
                        description=f"**{victim.display_name}** eliminated with **{tally[top_id]}** votes!\nThey were a {'🔪 **MAFIA**' if is_m else '🕊️ **CIVILIAN**'}!",
                        color=COLORS["error"]))
        finally: self._unlock(cid)

# ================================================================
#  GUESS THE SPY COG
# ================================================================
GTS_WORD_PAIRS=[
    ("Orange","Tangerine"),("Dog","Wolf"),("Piano","Keyboard"),("Ocean","Sea"),("Car","Automobile"),
    ("Happy","Joyful"),("Fire","Flame"),("Castle","Fortress"),("Phone","Telephone"),("Couch","Sofa"),
    ("Diamond","Gem"),("Chef","Cook"),("Movie","Film"),("Forest","Jungle"),("Ship","Vessel"),
    ("Apple","Pear"),("Lion","Tiger"),("Sun","Moon"),("Rain","Snow"),("Guitar","Violin"),
]

class GTSLobbyView(ui.View):
    def __init__(self,host):
        super().__init__(timeout=120); self.players=[host]; self.mode=None
    @ui.button(label="✋ Join",style=discord.ButtonStyle.success,row=0)
    async def join(self,interaction,button):
        if interaction.user in self.players: await interaction.response.send_message("✅ Already joined!",ephemeral=True); return
        self.players.append(interaction.user)
        await interaction.response.send_message(f"✅ **{interaction.user.display_name}** joined! ({len(self.players)} players)")
    @ui.button(label="🕵️ Normal",style=discord.ButtonStyle.primary,row=1)
    async def normal(self,interaction,button):
        if interaction.user!=self.players[0]: await interaction.response.send_message("❌ Only the host can start!",ephemeral=True); return
        if len(self.players)<3: await interaction.response.send_message("❌ Normal needs 3+ players!",ephemeral=True); return
        self.mode="normal"
        for child in self.children: child.disabled=True
        await interaction.response.edit_message(view=self); self.stop()
    @ui.button(label="👻 Wordless Spy",style=discord.ButtonStyle.danger,row=1)
    async def wordless(self,interaction,button):
        if interaction.user!=self.players[0]: await interaction.response.send_message("❌ Only the host can start!",ephemeral=True); return
        if len(self.players)<4: await interaction.response.send_message("❌ Wordless needs 4+ players!",ephemeral=True); return
        self.mode="wordless"
        for child in self.children: child.disabled=True
        await interaction.response.edit_message(view=self); self.stop()

class GTSVoteView(ui.View):
    def __init__(self,players):
        super().__init__(timeout=60); self.votes={}
        for p in players:
            btn=ui.Button(label=p.display_name[:20],style=discord.ButtonStyle.secondary,emoji="🗳️")
            btn.callback=self._make_cb(p.id,p.display_name); self.add_item(btn)
    def _make_cb(self,tid,name):
        async def cb(interaction):
            self.votes[interaction.user.id]=tid
            await interaction.response.send_message(f"🗳️ Voted for **{name}**!",ephemeral=True)
        return cb

class CloseChannelView(ui.View):
    def __init__(self,host): super().__init__(timeout=300); self.host=host
    @ui.button(label="🗑️ Close Channel",style=discord.ButtonStyle.danger)
    async def close(self,interaction,button):
        if interaction.user!=self.host: await interaction.response.send_message("❌ Only the host can close this.",ephemeral=True); return
        await interaction.response.send_message("🗑️ Closing in **3 seconds**…")
        await asyncio.sleep(3)
        try: await interaction.channel.delete(reason="GTS game ended")
        except: pass
        self.stop()

async def _create_gts_channel(guild,category,players):
    overwrites={
        guild.default_role: discord.PermissionOverwrite(view_channel=False,send_messages=False),
        guild.me: discord.PermissionOverwrite(view_channel=True,send_messages=True,manage_channels=True),
    }
    for player in players:
        overwrites[player]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
    staff_roles=[]; cfg=get_guild("config",guild.id); rid=cfg.get("staff_role_id")
    if rid:
        role=guild.get_role(int(rid))
        if role: staff_roles.append(role)
    for role in guild.roles:
        if role in staff_roles: continue
        if any(getattr(role.permissions,p,False) for p in ("kick_members","ban_members","manage_guild","administrator")):
            staff_roles.append(role)
    for role in staff_roles:
        overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=False,read_message_history=True)
    try:
        return await guild.create_text_channel(name="guess-the-spy",overwrites=overwrites,
            category=category,topic="🕵️ Guess The Spy — private game channel",reason="GTS game started")
    except: return None

class GTS(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.active_channels=set()

    @commands.hybrid_command(name="gts",description="🕵️ Guess The Spy — find the secret spy!")
    @commands.cooldown(1,30,commands.BucketType.channel)
    async def guess_the_spy(self,ctx):
        cid=ctx.channel.id
        if cid in self.active_channels:
            await ctx.reply(embed=make_embed(description="❌ A GTS game is already running!",color=COLORS["error"])); return
        self.active_channels.add(cid)
        try:
            view=GTSLobbyView(ctx.author)
            await ctx.send(embed=discord.Embed(title="🕵️ Guess The Spy — Lobby",
                description="**🟢 Normal Mode** *(3+ players)*\nEveryone gets the same word — the spy gets a *similar* word!\n\n**👻 Wordless Spy** *(4+ players)*\nThe spy has **NO word** and must bluff!\n\n━━━━━━━━━━━━━━━━━━━━\n"+f"👑 **Host:** {ctx.author.mention}\n\n✋ Click **Join**, then the **host** picks a mode!",
                color=COLORS["purple"]).set_footer(text="Lobby closes in 2 minutes"),view=view)
            try: await asyncio.wait_for(view.wait(),timeout=120)
            except asyncio.TimeoutError:
                await ctx.send(embed=make_embed(description="⏰ Lobby timed out.",color=COLORS["warning"])); return
            if not view.mode: return
            players=view.players; mode=view.mode
            gts_channel=await _create_gts_channel(ctx.guild,ctx.channel.category,players)
            if not gts_channel:
                await ctx.send(embed=make_embed(description="❌ Couldn't create private channel! Make sure bot has **Manage Channels** permission.",color=COLORS["error"])); return
            await ctx.send(embed=discord.Embed(title="🕵️ Game Starting!",
                description=f"Private channel created: {gts_channel.mention}\n\n**Players:** {' '.join(p.mention for p in players)}\n\nHead over there — roles are in your DMs!",
                color=COLORS["success"]))
            word_pair=random.choice(GTS_WORD_PAIRS); main_word=word_pair[0]
            spy_word=word_pair[1] if mode=="normal" else None; spy=random.choice(players); dm_failures=[]
            for p in players:
                if p==spy:
                    word_msg="🕵️ **You are the SPY!**\n\n"+(f"Your word: **`{spy_word}`**\n*Give clues — don't say it directly!*" if mode=="normal" else "⚠️ **You have NO word — bluff your way through!**")
                    color=COLORS["error"]
                else:
                    word_msg=f"🟢 **You are a Civilian!**\n\nYour word: **`{main_word}`**\n*Give clues — don't say it directly!*"
                    color=COLORS["success"]
                try: await p.send(embed=make_embed(title="🕵️ Guess The Spy — Your Role",description=word_msg,color=color))
                except: dm_failures.append(p.display_name)
            names=", ".join(p.display_name for p in players)
            await gts_channel.send(content=" ".join(p.mention for p in players),
                embed=discord.Embed(title=f"🕵️ Guess The Spy — {'Normal' if mode=='normal' else 'Wordless Spy'} Mode!",
                    description=f"**Players ({len(players)}):** {names}\n\n📬 Check your DMs for your role!\n\n🗣️ **Rules:**\n• Give one-word clues about your word\n• The spy must blend in!\n• After 3 min discussion → vote!\n\n⏱️ **3 minutes to discuss!**"+(f"\n\n⚠️ DM failed for: {', '.join(dm_failures)}" if dm_failures else ""),
                    color=COLORS["purple"]).set_footer(text="🔒 Staff can see but cannot chat"))
            for mins_left in [2,1]:
                await asyncio.sleep(60)
                await gts_channel.send(embed=make_embed(description=f"⏰ **{mins_left} minute{'s' if mins_left>1 else ''} left** before voting!",color=COLORS["warning"]))
            await asyncio.sleep(60)
            vote_view=GTSVoteView(players)
            vote_msg=await gts_channel.send(content=" ".join(p.mention for p in players),
                embed=discord.Embed(title="🗳️ Guess The Spy — Vote!",
                    description="⏰ **Discussion over!**\n\n🗳️ Vote for who you think is the **Spy!**\nYou have **60 seconds**!",
                    color=COLORS["warning"]),view=vote_view)
            await asyncio.sleep(60); vote_view.stop()
            for child in vote_view.children: child.disabled=True
            try: await vote_msg.edit(view=vote_view)
            except: pass
            tally={}
            for _,tid in vote_view.votes.items(): tally[tid]=tally.get(tid,0)+1
            if not tally:
                await gts_channel.send(embed=make_embed(description="🤷 No votes! The spy escapes!",color=COLORS["error"]))
            else:
                top_id=max(tally,key=tally.get); accused=next((p for p in players if p.id==top_id),None)
                if accused:
                    was_spy=accused==spy
                    spy_reveal=f"**Spy Word:** `{spy_word}`\n" if mode=="normal" and spy_word else "**Spy Word:** None *(Wordless mode)*\n"
                    await gts_channel.send(embed=discord.Embed(
                        title="✅ Spy Caught! Civilians Win! 🎉" if was_spy else "❌ Wrong! Spy Wins! 😈",
                        description=f"🗳️ **Most votes:** {accused.display_name} ({tally[top_id]} votes)\n🕵️ **The Spy was:** {spy.mention}\n🟢 **Main Word:** `{main_word}`\n{spy_reveal}"+("🎉 Civilians correctly identified the spy!" if was_spy else f"😈 **{spy.display_name}** successfully blended in!"),
                        color=COLORS["success"] if was_spy else COLORS["error"]).set_thumbnail(url=str(spy.display_avatar.url)))
            close_view=CloseChannelView(ctx.author)
            await gts_channel.send(embed=make_embed(description="🎮 **Game Over!** Thanks for playing.\n\nHost can close the channel, or it auto-deletes in **5 minutes**.",color=COLORS["primary"]),view=close_view)
            try: await asyncio.wait_for(close_view.wait(),timeout=300)
            except asyncio.TimeoutError:
                try: await gts_channel.delete(reason="GTS channel auto-deleted")
                except: pass
        finally: self.active_channels.discard(cid)

# ================================================================
#  MISC COG  (/google + /invite)
# ================================================================
HEADERS={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","Accept-Language":"en-US,en;q=0.9"}
BLACKLISTED_FROM_INVITE=set()
_SAFE_OPS={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.Pow:operator.pow,ast.Mod:operator.mod,ast.FloorDiv:operator.floordiv,ast.USub:operator.neg}

def _safe_eval(node):
    if isinstance(node,ast.Constant) and isinstance(node.value,(int,float)): return node.value
    if isinstance(node,ast.BinOp) and type(node.op) in _SAFE_OPS: return _SAFE_OPS[type(node.op)](_safe_eval(node.left),_safe_eval(node.right))
    if isinstance(node,ast.UnaryOp) and type(node.op) in _SAFE_OPS: return _SAFE_OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Unsafe")

def try_math(query):
    q=query.lower().strip().rstrip("?=")
    for pat,repl in [(r"\btimes\b","*"),(r"\bmultiplied by\b","*"),(r"\bdivided by\b","/"),(r"\bover\b","/"),(r"\bplus\b","+"),(r"\bminus\b","-"),(r"\bsquared\b","**2"),(r"\bcubed\b","**3"),(r"\bto the power of\b","**"),(r"\bwhat is\b",""),(r"\bwhat's\b",""),(r"\bcalculate\b",""),(r"\bsolve\b",""),(r"[,]","")]:
        q=re.sub(pat,repl,q)
    q=q.strip()
    if not q: return None
    try:
        result=_safe_eval(ast.parse(q,mode="eval").body)
        if isinstance(result,float) and result==int(result): result=int(result)
        return result
    except: return None

class Misc(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name="invite",description="🤖 Get the bot invite link (owner only)")
    async def invite(self,interaction:discord.Interaction):
        if interaction.user.id in BLACKLISTED_FROM_INVITE:
            await interaction.response.send_message(embed=make_embed(description="🚫 You are blacklisted.",color=COLORS["error"]),ephemeral=True); return
        if interaction.user.id!=OWNER_ID:
            await interaction.response.send_message(embed=make_embed(description="🔒 Owner only.",color=COLORS["error"]),ephemeral=True); return
        url=discord.utils.oauth_url(str(self.bot.user.id),permissions=discord.Permissions(administrator=True))
        await interaction.response.send_message(embed=make_embed(title="🤖 Invite PolarBot",
            description=f"[**Click here to invite PolarBot!**]({url})\n\n`{url}`",color=COLORS["primary"]),ephemeral=True)

    @app_commands.command(name="google",description="🔍 Ask anything — get a direct answer or top results")
    @app_commands.describe(query="Your question or search query")
    async def google(self,interaction:discord.Interaction,query:str):
        await interaction.response.defer()
        encoded=urllib.parse.quote_plus(query); answer_block=""; search_block=""
        math_result=try_math(query)
        if math_result is not None: answer_block=f"🧮 **Answer:** `{math_result}`"
        if not answer_block:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1",timeout=aiohttp.ClientTimeout(total=6)) as resp:
                        data=await resp.json(content_type=None)
                instant=(data.get("Answer") or "").strip(); abstract=(data.get("AbstractText") or "").strip(); definition=(data.get("Definition") or "").strip()
                if instant: answer_block=f"💡 **Answer:** {re.sub(r'<[^>]+>','',instant).strip()}"
                elif abstract:
                    short=abstract[:400]+("…" if len(abstract)>400 else ""); src=data.get("AbstractSource",""); src_url=data.get("AbstractURL","")
                    answer_block=f"📖 {short}"; answer_block+=f"\n— [*{src}*]({src_url})" if src and src_url else ""
                elif definition: answer_block=f"📚 **Definition:** {definition}"
            except: pass
        search_block=await self._web_search(query,encoded)
        parts=[]
        if answer_block: parts.append(answer_block)
        if search_block:
            if answer_block: parts.append("─────────────────\n🌐 **Top Results**")
            parts.append(search_block)
        description="\n\n".join(parts) if parts else f"😕 No results for **{query}**.\n[Search on Google](https://www.google.com/search?q={encoded})"
        e=discord.Embed(title=f"🔍 {query[:80]}",description=description[:3900],color=0x4285F4)
        e.set_thumbnail(url="https://www.google.com/favicon.ico")
        e.add_field(name="\u200b",value=f"[🔵 Google](https://www.google.com/search?q={encoded})  [🟠 DuckDuckGo](https://duckduckgo.com/?q={encoded})",inline=False)
        e.set_footer(text="PolarBot Search")
        await interaction.followup.send(embed=e)

    async def _web_search(self,query,encoded):
        try:
            from googlesearch import search as gsearch
            loop=asyncio.get_event_loop()
            raw=await asyncio.wait_for(loop.run_in_executor(None,lambda:list(gsearch(query,num_results=4,lang="en",advanced=True))),timeout=6)
            if raw:
                lines=[]
                for i,r in enumerate(raw[:4],1):
                    if hasattr(r,"title") and r.title and hasattr(r,"url"):
                        desc=(r.description[:80]+"…") if getattr(r,"description",None) else ""
                        lines.append(f"**{i}.** [{r.title[:65]}]({r.url})"+(f"\n> {desc}" if desc else ""))
                    elif hasattr(r,"url"): lines.append(f"**{i}.** {r.url}")
                if lines: return "\n\n".join(lines)
        except: pass
        try:
            async with aiohttp.ClientSession(headers=HEADERS) as session:
                async with session.get(f"https://html.duckduckgo.com/html/?q={encoded}",timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    html_content=await resp.text()
            results_list=[]; seen=set()
            for match in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',html_content,re.DOTALL):
                raw_url=match.group(1); raw_title=match.group(2); decoded=raw_url
                if "uddg=" in raw_url:
                    m=re.search(r"uddg=([^&]+)",raw_url)
                    if m: decoded=urllib.parse.unquote(m.group(1))
                title=re.sub(r"<[^>]+>","",raw_title).strip()[:65]
                if decoded not in seen and decoded.startswith("http") and title:
                    seen.add(decoded); results_list.append((title,decoded))
                if len(results_list)>=4: break
            if results_list: return "\n\n".join(f"**{i}.** [{t}]({u})" for i,(t,u) in enumerate(results_list,1))
        except: pass
        return ""

    @commands.Cog.listener()
    async def on_message(self,message:discord.Message):
        if message.author.bot: return
        if isinstance(message.channel,discord.DMChannel): await self.bot.process_commands(message)

# ================================================================
#  BOT EVENTS
# ================================================================
@bot.event
async def on_ready():
    await bot.tree.sync()
    await bot.change_presence(status=discord.Status.online,
        activity=discord.Activity(type=discord.ActivityType.watching,name=f"{len(bot.guilds)} servers | ,help"))
    print(f"✅  Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"✅  Slash commands synced.")
    print(f"✅  Serving {len(bot.guilds)} guilds.")

@bot.event
async def on_message_delete(message:discord.Message):
    if message.author.bot: return
    bot.snipe_cache[message.channel.id]={"content":message.content or "[No text]","author_name":str(message.author),"author_avatar":str(message.author.display_avatar.url),"timestamp":message.created_at.isoformat()}

@bot.event
async def on_message_edit(before:discord.Message,after:discord.Message):
    if before.author.bot or before.content==after.content: return
    bot.editsnipe_cache[before.channel.id]={"before":before.content or "[No text]","after":after.content or "[No text]","author_name":str(before.author),"author_avatar":str(before.author.display_avatar.url),"timestamp":before.created_at.isoformat()}

@bot.event
async def on_message(message:discord.Message):
    if message.author.bot: return
    afk_data=load("afk"); uid=str(message.author.id)
    if uid in afk_data:
        del afk_data[uid]; save("afk",afk_data)
        try:
            await message.channel.send(embed=make_embed(description=f"👋 Welcome back, {message.author.mention}! AFK removed.",color=0x57F287),delete_after=5)
        except: pass
    if message.mentions and message.guild:
        for mentioned in message.mentions:
            mid=str(mentioned.id)
            if mid in afk_data:
                entry=afk_data[mid]
                await message.channel.send(embed=make_embed(description=f"💤 **{mentioned.display_name}** is AFK\n**Reason:** {entry.get('reason','No reason')}\n**Since:** <t:{entry.get('since',0)}:R>",color=0xFEE75C),delete_after=8)
    if message.guild:
        sticky_data=get_guild("sticky",message.guild.id); cid=str(message.channel.id)
        if cid in sticky_data:
            info=sticky_data[cid]
            try:
                old=await message.channel.fetch_message(info["message_id"]); await old.delete()
            except: pass
            new_msg=await message.channel.send(embed=make_embed(title="📌 Sticky Message",description=info["content"],color=0xF1C40F))
            info["message_id"]=new_msg.id; sticky_data[cid]=info; set_guild("sticky",message.guild.id,sticky_data)
    await bot.process_commands(message)

@bot.event
async def on_command_error(ctx,error):
    if isinstance(error,commands.CommandNotFound): return
    if isinstance(error,commands.MissingRequiredArgument):
        await ctx.reply(embed=make_embed(description=f"❌ **Missing argument:** `{error.param.name}`\nUse `,help` for usage.",color=0xED4245))
    elif isinstance(error,commands.MemberNotFound):
        await ctx.reply(embed=make_embed(description="❌ **Member not found.**",color=0xED4245))
    elif isinstance(error,commands.CommandOnCooldown):
        await ctx.reply(embed=make_embed(description=f"⏳ **Slow down!** Try again in **{error.retry_after:.1f}s**.",color=0xFEE75C),delete_after=4)
    elif isinstance(error,commands.CheckFailure): pass
    else:
        await ctx.reply(embed=make_embed(description=f"⚠️ An error occurred: `{error}`",color=0xED4245))

# ================================================================
#  HELP COMMAND
# ================================================================
@bot.command(name="help")
async def help_cmd(ctx):
    e=discord.Embed(title="❄️ PolarBot — Commands",
        description="> Prefix: `,` or `!`  ·  All commands also work as `/slash`\n─────────────────────────────────",
        color=0x5865F2)
    e.set_thumbnail(url=bot.user.display_avatar.url)
    e.add_field(name="🛡️ Moderation  *(Staff only)*",
        value="`rn`  `delete`  `ps`  `warn`  `unwarn`  `warnings`  `kick`  `ban`  `unban`  `mute`  `unmute`  `userinfo`  `purge`",inline=False)
    e.add_field(name="🔧 Utility",
        value="`afk`  `vouch`  `snipe`  `editsnipe`  `sticky`  `unsticky`  `setstats`  `confess`",inline=False)
    e.add_field(name="🤖 Auto Response  *(Staff only)*",
        value="`autoresponse add`  `autoresponse remove`  `autoresponse list`",inline=False)
    e.add_field(name="🚫 AutoMod  *(Staff only)*",
        value="`automodadd`  `automodremove`  `automodwhitelist`  `automodunwhitelist`  `automodlist`",inline=False)
    e.add_field(name="🎮 Games",
        value="`rps`\n`trivia`\n`tictactoe`\n`connect4`\n`wordchain`\n`hangman`\n`fasttype`\n`memorymatch`\n`wouldyourather`\n`mafia`\n`gts`",
        inline=False)
    e.add_field(name="⚙️ Misc",value="`/google`  `/invite`",inline=False)
    e.set_footer(text=f"PolarBot 2.0  ·  {len(bot.guilds)} servers")
    await ctx.send(embed=e)

# ================================================================
#  ENTRY POINT
# ================================================================
async def main():
    async with bot:
        await bot.add_cog(Moderation(bot))
        await bot.add_cog(Utility(bot))
        await bot.add_cog(AutoResponse(bot))
        await bot.add_cog(AutoMod(bot))
        await bot.add_cog(Games(bot))
        await bot.add_cog(PartyGames(bot))
        await bot.add_cog(GTS(bot))
        await bot.add_cog(Misc(bot))
        print("✅  All cogs loaded.")
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
